notas = [5, 10, 7.5]
console.log(notas)
notas.pop() // remove um elemento do array
console.log(notas)
console.log(notas)
notas.push(9)   // adiciona elementos no array
console.log(notas)
notas.push(10)  // adiciona elementos no array
console.log(notas)