const numeros = [1, 2, 3, 4]
const quadrados = numeros.map(num => num*num)
// map é uma função que aplica na lista para elevar os números ao quadrado
console.log(quadrados)