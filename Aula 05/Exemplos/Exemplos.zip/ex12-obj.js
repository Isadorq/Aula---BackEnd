// Cria um objeto vazio e adiciona os atributos
carro = {}
carro.modelo = "Jaguar"
carro.ano = 2024
carro.combustível = "Híbrido"
carro.portas = 5
carro.acelera = function(){
    return 'O carro está acelerando'
}
console.log(carro)
console.log(carro.acelera())