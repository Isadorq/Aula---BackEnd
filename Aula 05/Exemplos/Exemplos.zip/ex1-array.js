const frutas = ['Pera', 'Uva', 'Maçã']; // cria um array(lista) chamado frutas
console.log(frutas);
console.log(frutas[2])  // acessa o elemento 2 do array

const frutas2 = new Array('Maçã', 'Morango', 'Laranja') //segunda forma de criar array
console.log(frutas2[1]); // acessa o elemento 1