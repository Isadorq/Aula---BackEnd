const numeros = [1, 2, 3, 4, 5]
const pares = numeros.filter(num => num %2==0) 
    console.log(pares)
//forma de calcular o resto de um número
num = numeros % 2
if (num===0){
    console.log(num)
}