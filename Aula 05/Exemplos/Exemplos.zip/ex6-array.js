nomes = ['Daniel', 'Bruna', 'Camila', 'Julia']
// forEach - itera os elementos da lista 
nomes.forEach(function (nomes, index){
    console.log(nomes, index)

});
for (i=0; i<nomes.lenght;i++){
    console.log(`${i} ${nomes[i]}`)
}