// notas = [10, 9, 8, 5, 6]    // cria um array de notas
// console.log(notas)   // exibe o array de notas
// notas.unshift(7.7)  // adiciona elementos no array na esquerda
// console.log(notas)
// notas.unshift(6.5)
// console.log(notas)
// notas.shift(7)
notas = [10, 9, 8, 5, 6]
console.log(notas)
notas.shift(7.7)
console.log(notas)
notas.shift()   // remove elementos 
console.log(notas)
notas.pop(5)
console.log(notas)